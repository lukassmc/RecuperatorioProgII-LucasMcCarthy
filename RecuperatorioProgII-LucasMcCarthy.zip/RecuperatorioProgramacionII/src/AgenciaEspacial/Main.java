
package AgenciaEspacial;


public class Main {
    public static void main(String[] args) {
    
        Agencia agencia = new Agencia("Agencia Espacial");

      
        try {
            Carguero carguero1 = new Carguero("Carguero Galactico", 3, 2024, 300); 
            agencia.agregarNave(carguero1);

         
            Carguero cargueroDuplicado = new Carguero("Carguero Galactico", 3, 2024, 200);
            agencia.agregarNave(cargueroDuplicado);
        } catch (NaveDuplicadaException e) {
            System.out.println(e.getMessage());
        }


        NaveExploracion exploracion1 = new NaveExploracion("Explorator E1", 8, 2023, TipoMision.INVESTIGACION);
        CruceroEstelar crucero1 = new CruceroEstelar("Estrella de Muerte", 50, 2022, 150);
        
        try {
            agencia.agregarNave(exploracion1);
            agencia.agregarNave(crucero1);
        } catch (NaveDuplicadaException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nListado de naves en la agencia:");
        agencia.mostrarNaves();

        
        System.out.println("\nIniciando mision de exploracion para las naves:");
        agencia.iniciarExploracion();
    }
}

