
package AgenciaEspacial;

import java.util.Objects;

public abstract class Nave {


    protected String nombre;
    protected int capacidadTripulacion ;
    protected int anioLanzamiento;
    
     public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
     
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + Objects.hashCode(this.nombre);
        hash = 83 * hash + this.anioLanzamiento;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nave other = (Nave) obj;
        if (this.anioLanzamiento != other.anioLanzamiento) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }
    

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public int getAnioLanzamiento() {
        return anioLanzamiento;
    }
    
    
}
