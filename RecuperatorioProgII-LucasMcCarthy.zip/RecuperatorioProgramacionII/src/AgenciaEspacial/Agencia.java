
package AgenciaEspacial;
import java.util.ArrayList;

public class Agencia {
    private String nombre;
    private ArrayList<Nave> naves;

    public Agencia(String nombre) {
        this.nombre = nombre;
        this.naves = new ArrayList<>();
    }
    
    
public void agregarNave(Nave nave) throws NaveDuplicadaException {
    for (Nave n : naves) {
        if (n.equals(nave)) {  
            throw new NaveDuplicadaException("La nave llamada " + nave.getNombre() + " y  con anio de lanzamiento " + nave.getAnioLanzamiento() + " ya existe.");
        }
    }
    naves.add(nave);  
}

    
public void mostrarNaves() {
    if (naves.isEmpty()) {
        System.out.println("No hay naves en la Agencia.");
    } else {
        for (Nave nave : naves) {
            System.out.println(nave.toString());  
        }
    }
}

    
public void iniciarExploracion() {
    for (Nave nave : naves) {
        if (nave instanceof CruceroEstelar) {
            System.out.println("La nave " + nave.getNombre() + " es un crucero estelar y no puede iniciar una exploracion ya que no puede explorar..");
        } else if (nave instanceof Explorable) {
            ((Explorable) nave).explorar();
        }
    }
}


}

     




