
package AgenciaEspacial;

public enum TipoMision {
    CARTOGRAFIA, 
INVESTIGACION, 
CONTACTO

}
