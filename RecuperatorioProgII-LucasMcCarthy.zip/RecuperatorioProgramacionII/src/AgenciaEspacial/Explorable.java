
package AgenciaEspacial;

public interface Explorable {
       
    public void explorar();
}
