
package AgenciaEspacial;

public class Carguero extends Nave implements Explorable{

    private int capacidadCarga;
    
    
    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.capacidadCarga = capacidadCarga;
    }

  @Override
    public void explorar() { 
        System.out.println("La nave "+ nombre + " ha comenzado a explorar!");
        
    }
   @Override
    public String toString() {
        return "Carguero{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", anioLanzamiento=" + anioLanzamiento + "capacidadCarga" + capacidadCarga + '}';
    }
    
    
    
}
